motor_matic = 50.000
motor_trail = 100.000
motor_sport = 75.000
asuransi = 15.000

while True: 
    print(input("jenis motor: "))
    print(input("harga motor: " ))
    print(input("sewa berapa hari: "))

    if  "matic":
        (input(harga_motor = "50.000" ))
        (input(sewa_berapa_hari = "sewa berapa hari" ))

    if "trail":
        (input(harga_motor = "harga motor" ))
        (input(sewa_berapa_hari = "sewa berapa hari" ))