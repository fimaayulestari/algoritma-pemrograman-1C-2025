# Repository praktikum Algoritma Pemrograman 1A-2025

**Repository Praktikum ALPRO-1A-2025.**

Kumpulkan Tugas di folder ini yang sudah dibuat, penamaan folder dengan **format NIM-NamaLengkap-NamaLengkapAsprak**, dan untuk nama tidak menggunakan spasi, namun diganti dengan huruf kapital di setiap nama atau awal kalimat
contoh: **230441100026-Ar'raffiAbqoriNurAzizi-AsprakKakRapi**

Kumpulkan tugas yang sudah dibuat di folder yang sudah disediakan dan kumpulkan tugas ketika sudah melakukan asistensi kepada Asisten Praktikum.
