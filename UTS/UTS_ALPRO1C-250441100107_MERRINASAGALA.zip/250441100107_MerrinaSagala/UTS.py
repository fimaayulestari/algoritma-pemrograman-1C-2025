#PROGRAM RENTAL MOTOR 
print ("/n=== jenis jenis motor sewa:===")
print ("1. Motor matic = Rp50000.00")
print ("2. Motor trail = Rp100000.00")
print ("3. Motor sport = 75000.00")

subtotal = 0
waktu_penyewaan = 0

#asuransi jika lebih dari 3hari
while True:
        
        waktu_penyewaan>= 3 (f"mendapat asuransi sebesar {Rp15000:} ")
        break

#DISKON JIKA SUBTOTAL BELANJA

if subtotal >=float(subtotal >= 15000.00):
        diskon = 0.10
elif (input("apakah memiliki kupon? (y/n)")):
        diskon = 0.5
else : 
        diskon = 0

input("melakukan penyewaan lagi?(y/n)")
pass 

