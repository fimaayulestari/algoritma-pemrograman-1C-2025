
print("Rental motor aconk")
jenis = 0
hargasewa = 0

print("Motormatic = 50000")
print("Motortrail = 100.000")
print("Motorsport = 75000")

jenis =input(str("masukkanjenismotor="))
print(jenismotor("masukkanjenismotor="))

lamasewa =input(int("Masukkanlamasewa="))
print(lamasewa("Masukkanlamasewa="))

if jikasewa>3 ("kelipatan3"):
   print (int("asuransi 0.15"))
   continue

if tidakterjadikelipatan("subtotallebihdari150.000"):
    print (int("diskon 0.1"))
    continue

if memasukkankupon("AconkGG"):
   print(int("diskon tambahan 0.5"))
   break

print("hargatotal")


