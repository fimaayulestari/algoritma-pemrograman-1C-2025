#Program rental motor Aconk

hargasewamotormatic : 50000
hargasewamotortrail : 100000
hargasewamotorsport : 75000

n = int(input(" pilihan jenis motor"),n, +1, ":")
n =(float("harga motor tiap jenis"), n, +1, ":")
n =(float("asuransi jika lebih dari 3 hari penyewaaan"))
    print : 10 ** 100